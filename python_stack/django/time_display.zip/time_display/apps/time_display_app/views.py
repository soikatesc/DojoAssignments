from django.shortcuts import render
import datetime

# Create your views here.

def index(request):
	d = datetime.datetime.now()

	print type(d)
	date = d.date()
	time = d.time() 

	date_time = {
	'date':date,
	'time':time
	}
  	return render(request, 'time_display_app/index.html', date_time)

