from __future__ import unicode_literals

from django.apps import AppConfig


class PortfolioAppConfig(AppConfig):
    name = 'portfolio_app'
