from __future__ import unicode_literals

from django.apps import AppConfig


class RealPortfolioAppConfig(AppConfig):
    name = 'real_portfolio_app'
