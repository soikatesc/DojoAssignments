

var x = 7;
console.log(x);