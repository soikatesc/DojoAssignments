from __future__ import unicode_literals

from django.apps import AppConfig


class FullStackBooksAppConfig(AppConfig):
    name = 'full_stack_books_app'
