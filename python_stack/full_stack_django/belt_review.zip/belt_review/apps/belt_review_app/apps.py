from __future__ import unicode_literals

from django.apps import AppConfig


class BeltReviewConfig(AppConfig):
    name = 'belt_review_app'
